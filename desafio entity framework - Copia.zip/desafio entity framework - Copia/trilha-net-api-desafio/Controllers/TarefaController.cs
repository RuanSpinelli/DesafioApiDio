using Microsoft.AspNetCore.Mvc;
using TrilhaApiDesafio.Context;
using TrilhaApiDesafio.Models;

namespace TrilhaApiDesafio.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TarefaController : ControllerBase
    {
        private readonly OrganizadorContext _context;

        public TarefaController(OrganizadorContext context)
        {
            _context = context;
        }

        [HttpGet("{id}")] // feito
        public IActionResult ObterPorId(int id)
        {
           var tarefa = _context.Tarefas.Find(id); //define qual tarefa exatamente será procurada

            if (tarefa == null)
            {
                return NotFound(); // Retorna 404 Not Found se a tarefa não for encontrada
            }

            return Ok(tarefa); // Retorna 200 OK com a tarefa encontrada
        }

        [HttpGet("ObterTodos")] //feito
        public IActionResult ObterTodos()
        {
            var tarefas = _context.Tarefas.ToList();
            return Ok(tarefas); // Retorna 200 OK com todas as tarefas encontradas
        }

        [HttpGet("ObterPorTitulo")] //feito 
        public IActionResult ObterPorTitulo(string titulo)
        {
            var tarefas = _context.Tarefas.Where(t => t.Titulo.Contains(titulo)).ToList();

            return Ok(tarefas); // Retorna 200 OK com todas as tarefas encontradas que contêm o título fornecido
        }

        [HttpGet("ObterPorData")] //feito 
        public IActionResult ObterPorData(DateTime data)
        {
            var tarefas = _context.Tarefas.Where(x => x.Data.Date == data.Date).ToList();
            return Ok(tarefas);
        }

        [HttpGet("ObterPorStatus")]
        public IActionResult ObterPorStatus(EnumStatusTarefa status)
        {
            var tarefas = _context.Tarefas.Where(x => x.Status == status).ToList();

            if (tarefas.Count == 0)
            {
                return NotFound(); // Retorna 404 Not Found se nenhuma tarefa for encontrada com o status especificado
            }

            return Ok(tarefas); // Retorna 200 OK com todas as tarefas encontradas com o status especificado
        }

        [HttpPost("Criar tarefa")]
        public IActionResult Criar(Tarefa tarefa)
        {
            if (tarefa.Data == DateTime.MinValue)
            {
                return BadRequest(new { Erro = "A data da tarefa não pode ser vazia" });
            }

            // Adiciona a tarefa ao contexto
            _context.Tarefas.Add(tarefa);

            // Salva as mudanças no banco de dados
            _context.SaveChanges();

            // Retorna 201 Created com o ID da tarefa criada
            return CreatedAtAction(nameof(ObterPorId), new { id = tarefa.Id }, tarefa);
        }

        [HttpPut("{id}")]
        public IActionResult Atualizar(int id, Tarefa tarefa)
        {
            var tarefaBanco = _context.Tarefas.Find(id);

            if (tarefaBanco == null)
            {
                return NotFound(); // Retorna 404 Not Found se a tarefa não foi encontrada
            }

            if (tarefa.Data == DateTime.MinValue)
            {
                return BadRequest(new { Erro = "A data da tarefa não pode ser vazia" }); // Retorna 400 Bad Request se a data da tarefa for inválida
            }

            // Atualiza as informações da tarefa existente com os dados recebidos
            tarefaBanco.Titulo = tarefa.Titulo;
            tarefaBanco.Descricao = tarefa.Descricao;
            tarefaBanco.Status = tarefa.Status;
            tarefaBanco.Data = tarefa.Data;

            // Atualiza a tarefa no contexto
            _context.Tarefas.Update(tarefaBanco);

            // Salva as mudanças no banco de dados
            _context.SaveChanges();

            return Ok(); // Retorna 200 OK indicando que a tarefa foi atualizada com sucesso
        }


        [HttpDelete("{id}")]
        public IActionResult Deletar(int id)
        {
            var tarefaBanco = _context.Tarefas.Find(id);

            if (tarefaBanco == null)
            {
                return NotFound(); // Retorna 404 Not Found se a tarefa não foi encontrada
            }

            // Remove a tarefa do contexto
            _context.Tarefas.Remove(tarefaBanco);

            // Salva as mudanças no banco de dados
            _context.SaveChanges();

            return NoContent(); // Retorna 204 No Content indicando que a tarefa foi removida com sucesso
        }

    }
}
